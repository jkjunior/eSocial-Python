        if value < 0:
            return False
        else:
            return True


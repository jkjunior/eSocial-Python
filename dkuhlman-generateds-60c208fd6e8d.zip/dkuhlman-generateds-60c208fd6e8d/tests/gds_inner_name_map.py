
Inner_name_map = {
    ("classAType", "inner"): "inner_001",
    ("classBType", "inner"): "inner_002",
    #("classAType", "inner"): "class_a_inner",
    #("classBType", "inner"): "class_b_inner",
}
